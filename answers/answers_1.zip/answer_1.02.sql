-- Filter rows where the station name is `'TACOMA NUMBER 1, WA US'`.
SELECT * 
FROM weather
WHERE name = 'TACOMA NUMBER 1, WA US'